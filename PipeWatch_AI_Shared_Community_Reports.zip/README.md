# PipeWatch AI - underground pipeline leakage reporting platform

## Included
- `index.html`: responsive PipeWatch AI dashboard with Firebase email/password authentication, user profile, private underground pipeline leakage reports, maps and insights.
- `firebase.json` and `.firebaserc`: Firebase Hosting configuration targeting `roadvision-ai-4e1ea`.
- `firestore.rules`: each signed-in user can access only their own profile and reports.

## Before the practical
1. In Firebase Console, open **Authentication → Sign-in method** and enable **Email/Password**.
2. Open **Authentication → Settings → Authorized domains** and add the exact domain serving the site (for Firebase Hosting this is normally `roadvision-ai-4e1ea.web.app` and `roadvision-ai-4e1ea.firebaseapp.com`).
3. Create the Cloud Firestore database if it does not exist.
4. Publish `firestore.rules` in Firestore → Rules. The rules in this folder are user-scoped.

The website can be previewed from a local web server, but browser modules and geolocation work best on HTTPS. Firebase project-side settings cannot be changed by editing this ZIP.

## Deploy
From this folder, after Firebase CLI login:
```bash
npx firebase-tools deploy --only hosting,firestore:rules
```

## What was fixed
- Correct desktop flex layout and sticky desktop sidebar; mobile drawer retained.
- Auth buttons always restore their labels and become clickable after success/failure/timeout.
- Shorter bounded auth waits and clearer Firebase error messages.
- Dashboard opens immediately from the authenticated Firebase user; Firestore profile lookup no longer blocks it.
- Report listener checks the active user and reports permission errors clearly.
- Map library failures no longer interrupt dashboard startup.

## Data model
- `users/{uid}`: display name and email.
- `users/{uid}/reports/{reportId}`: title, coordinates, pipeline leakage status, notes and timestamp.
- Passwords are handled only by Firebase Authentication.

## Photo evidence on reports
- The report form now accepts an optional JPG, PNG, or WebP photo (up to 8 MB).
- The browser resizes/compresses the image before saving it as `photoDataUrl` on the same Firestore report document. This avoids requiring a separate Storage bucket setup for this demo.
- Photos appear in the report list and in map-marker popups. Existing reports without a photo continue to work.
- Images are compressed to stay below the Firestore document-size limit. For a production deployment with many high-resolution photos, move image files to Firebase Storage and keep only their download URLs in Firestore.


Frontend adaptation note: The interface now presents user-submitted suspected underground pipeline leakage observations. Firebase Authentication, Firestore collection paths, document fields, and security rules are intentionally preserved for backend compatibility. The existing `pothole` field remains an internal legacy field storing yes/no observation status; it is not displayed to users. The website is a software-based, user-reporting and location-mapping platform. It does not require hardware sensors and does not claim autonomous underground sensing. Reports are observations submitted by users, supported by photos and GPS coordinates.
